// src/components/Training/TrainingComponent.tsx
import { TrainingPage } from './TrainingPage';

export function TrainingComponent() {
  return (
    <div>
      <h1>Тренировки</h1>
      <TrainingPage />
    </div>
  );
}