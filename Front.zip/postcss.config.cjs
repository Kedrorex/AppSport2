// postcss.config.cjs
module.exports = {
  plugins: {
    'postcss-preset-mantine': {},
  },
};